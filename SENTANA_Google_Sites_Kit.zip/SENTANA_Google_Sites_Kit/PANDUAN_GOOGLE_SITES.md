# SENTANA — Panduan Pembuatan Google Sites

## Penting
File `index.html` merupakan **prototype website untuk referensi visual**, bukan file yang dapat langsung diimpor menjadi tema Google Sites. Untuk Google Sites, susun halaman memakai blok tata letak, teks dan gambar; kemudian unggah aset dari folder `assets` satu per satu. Jangan mempublikasikan konten simulasi seolah-olah penjualan nyata.

## Pengaturan identitas
- Nama situs: SENTANA | Seni Tekstil Alam Nusantara
- Tagline: Menyulam Budaya, Mengalun Jiwa.
- Nuansa: modern Indonesian heritage, minimal, editorial.
- Warna: maroon `#571C20`, hijau mangrove `#465A36`, terracotta `#B66B44`, cream `#FAF6ED`, cokelat teks `#382A26`.
- Judul: pilih font serif paling mendekati Playfair Display dalam pilihan tema Google Sites; isi: font sans-serif bersih. Google Sites memiliki batasan tema/font dibanding HTML prototype.
- Logo utama: `assets/logo.png` (logo yang disetujui pengguna), jangan digambar ulang.
- Navigasi: atas. Menu: Home, Our Story, Collection, Mix & Match, Our Impact, Pre-Order.
- Untuk setiap halaman, gunakan header besar, section 2 kolom atau 3 kartu, CTA berulang secukupnya, dan footer konsisten.

## Halaman 1: HOME
Header besar (gambar `assets/hero.jpg` atau `assets/editorial.jpg`):
Judul: Wear the story. Live the heritage.
Subjudul: SENTANA menghidupkan kembali kisah batik dan potensi pewarna alami mangrove Rungkut melalui fashion modular yang modern, fleksibel, dan bermakna.
Tombol: Explore Collection → halaman Collection. Discover Our Story → halaman Our Story.
Section 2: Rooted in heritage. Designed for today.
Isi: Kami memadukan nilai budaya lokal, kolaborasi bersama perajin, dan desain multifungsi agar wastra Indonesia terasa dekat dengan kehidupan generasi baru.
Section 3: tiga kolom: Nature / Culture / Function dengan ringkasan seperti di prototype.
Section 4: foto editorial plus teks: A new expression of batik.
Banner akhir: Satu motif. Banyak kemungkinan. Cerita yang terus hidup.

## Halaman 2: OUR STORY
Header: Born from nature. Woven with meaning.
Keterangan: SENTANA = Seni Tekstil Alam Nusantara. Konsep bisnis pemanfaatan potensi biomassa mangrove Rungkut dan batik lokal menjadi fashion modular.
Susun 4 kartu proses: Explore → Co-create → Design → Validate.
Tambahkan motif `assets/motif-cream.jpg` dan kutipan “Menyulam Budaya, Mengalun Jiwa.”
Catatan: kolaborasi dan pewarnaan masih berupa rencana/pengembangan bila belum terlaksana.

## Halaman 3: COLLECTION
Header: Made to move with you.
Buat 3 kartu produk (foto, nama, 1–2 kalimat, estimasi harga, status):
- Multiway Scarf: variasi neck scarf, headscarf, shawl, aksen tas, scarf top. Estimasi Rp150.000. Gambar `assets/scarf.jpg`.
- Modular Outer / Vest: interpretasi outer/vest dengan fungsi modular. Estimasi Rp300.000. Gambar `assets/outer.jpg`.
- Modular Wrap Skirt: rok dasar midi + detachable length extension + detachable draped panel. Estimasi Rp250.000. Gambar `assets/look-skirt.jpg`.
Tambahkan dua pola signature dari `assets/motif-maroon.jpg`, `assets/motif-cream.jpg`.
WAJIB tampilkan “Visualisasi desain / mockup. Produk dalam tahap pengembangan. Harga estimasi.”

## Halaman 4: MIX & MATCH
Header: One piece. Many stories.
Gunakan 3 foto di blok gambar: `assets/hijab.jpg`, `assets/editorial.jpg`, `assets/look-skirt.jpg`.
Teks: Scarf as Headwear / Outer Statement / Everyday Long Skirt.
Section: Not just another wrap. Modular Wrap Skirt terdiri dari basic midi skirt, detachable length extension, detachable draped panel. Jelaskan pengunci masih diuji dalam prototipe.

## Halaman 5: OUR IMPACT
Header: Our Impact Vision.
Buat 3 kartu: Environment / Economy / Community.
Gunakan pernyataan berorientasi rencana, bukan dampak terverifikasi.
Contoh: Rencana pemanfaatan biomassa mangrove; co-creation bersama perajin Rungkut; pelibatan penjahit dan edukasi wastra.
Bagian Packaging Concept: `assets/packaging.jpg` dan teks keranjang anyaman reusable, storytelling card, hang tag, pouch, thank-you card.

## Halaman 6: PRE-ORDER
Header: Coming soon.
Pernyataan: SENTANA sedang mempersiapkan validasi desain, prototipe, dan rencana pre-order. Belum ada checkout atau stok aktif.
Buat satu CTA “Join the Interest List” → tautkan ke Google Form hanya setelah form resmi dibuat.
Buat CTA “Chat on WhatsApp” → tambahkan nomor WhatsApp Business resmi setelah tersedia. Tidak ada nomor dummy.
FAQ: ketersediaan, pewarna alami, cara pre-order, peluang kolaborasi.
Jika nanti BRImo/QRIS/BRIVA diaktifkan, barulah tambahkan detail metode pembayaran sesuai layanan yang benar-benar aktif.

## Cara menaruhnya ke Google Sites
1. Buka sites.google.com → Blank → tulis nama situs.
2. Themes → buat tema kustom bila tersedia, dengan warna di atas.
3. Pages → buat 6 halaman persis sesuai menu di atas.
4. Insert → pilih layout gambar + teks / 3 kolom. Salin konten per halaman dari panduan dan contoh HTML.
5. Insert → Images → Upload dari folder `assets`.
6. Atur tombol menggunakan Insert → Button, lalu link ke halaman internal.
7. Preview desktop dan mobile; potong ulang gambar yang terlalu tinggi dengan crop.
8. Publish ke alamat pilihan pengguna setelah semua teks, kontak, dan klaim diperiksa.

## Sebelum publikasi
- Pastikan logo dipakai sesuai master yang disetujui.
- Motif master asli tetap disimpan; mockup kain bisa berbeda dari artwork cetak final.
- Pastikan izin penggunaan foto dan ilustrasi; visual generatif adalah konsep, bukan dokumentasi produk asli.
- Data 47 responden dan klaim survei jangan dipublikasikan tanpa memastikan survei benar-benar dilaksanakan dan data mentah tersedia.
- Hindari klaim “sudah bekerja sama dengan BRI/perajin” bila belum ada kerja sama formal.
- Pastikan harga dan status pre-order telah diperbarui sebelum menerima pembayaran.
